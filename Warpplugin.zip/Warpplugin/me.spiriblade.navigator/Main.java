package me.jaymar.navigation;

import org.bukkit.plugin.java.*;
import me.jaymar.navigation.dataHandler.*;
import org.bukkit.plugin.*;
import org.bukkit.event.*;
import net.md_5.bungee.api.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.entity.*;
import org.bukkit.enchantments.*;
import java.util.*;
import org.bukkit.command.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.event.inventory.*;

public class Main extends JavaPlugin implements Listener
{
    public Inventory inv;
    public dataHandler data;
    Location hub;
    Location skyblock;
    Location oneblock;
    Location minigames;
    Location market;

    public void onEnable() {
        this.createInventory();
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        this.data = new dataHandler(this);
        this.loadMap();
    }

    public void onDisable() {
    }

    @EventHandler
    public void onJoin(final PlayerJoinEvent event) {
        this.giveNavigationItem(event.getPlayer());
    }

    public void createInventory() {
        this.inv = Bukkit.createInventory((InventoryHolder)null, 9, new StringBuilder().append(ChatColor.BOLD).append(ChatColor.DARK_AQUA).append(ChatColor.BOLD).append("Navigation by").append(ChatColor.LIGHT_PURPLE).append(ChatColor.BOLD).append(" JayMar").toString());
        final ItemStack item = new ItemStack(Material.BEACON);
        final ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(new StringBuilder().append(ChatColor.GOLD).append(ChatColor.BOLD).append("HUB").toString());
        item.setItemMeta(meta);
        this.inv.setItem(0, item);
        item.setType(Material.GRASS_BLOCK);
        final ItemMeta meta2 = item.getItemMeta();
        meta2.setDisplayName(new StringBuilder().append(ChatColor.BLUE).append(ChatColor.BOLD).append("SKY BLOCK ").toString());
        item.setItemMeta(meta2);
        this.inv.setItem(1, item);
        item.setType(Material.DIRT);
        final ItemMeta meta3 = item.getItemMeta();
        meta3.setDisplayName(new StringBuilder().append(ChatColor.YELLOW).append(ChatColor.BOLD).append("ONE BLOCK").toString());
        item.setItemMeta(meta3);
        this.inv.setItem(2, item);
        item.setType(Material.TURTLE_EGG);
        final ItemMeta meta4 = item.getItemMeta();
        meta4.setDisplayName(new StringBuilder().append(ChatColor.AQUA).append(ChatColor.BOLD).append("MINIGAMES").toString());
        item.setItemMeta(meta4);
        this.inv.setItem(3, item);
        item.setType(Material.CHEST);
        final ItemMeta meta5 = item.getItemMeta();
        meta5.setDisplayName(new StringBuilder().append(ChatColor.RED).append(ChatColor.BOLD).append("MARKET").toString());
        item.setItemMeta(meta5);
        this.inv.setItem(4, item);
        item.setType(Material.RED_STAINED_GLASS_PANE);
        final ItemMeta meta6 = item.getItemMeta();
        meta6.setDisplayName(new StringBuilder().append(ChatColor.DARK_PURPLE).append(ChatColor.BOLD).append("[---]").toString());
        item.setItemMeta(meta6);
        this.inv.setItem(5, item);
        this.inv.setItem(6, item);
        this.inv.setItem(7, item);
        item.setType(Material.OAK_SIGN);
        final ItemMeta meta7 = item.getItemMeta();
        meta7.setDisplayName(new StringBuilder().append(ChatColor.DARK_AQUA).append(ChatColor.BOLD).append("Exit Navigation").toString());
        item.setItemMeta(meta7);
        this.inv.setItem(8, item);
    }

    public void giveNavigationItem(final Player player) {
        if (!player.getInventory().contains(Material.NETHER_STAR)) {
            final ItemStack item = new ItemStack(Material.NETHER_STAR);
            item.addUnsafeEnchantment(Enchantment.DURABILITY, 1);
            final ItemMeta meta = item.getItemMeta();
            final List<String> lore = new ArrayList<String>();
            meta.setDisplayName(new StringBuilder().append(ChatColor.BOLD).append(ChatColor.BLUE).append("Navigation").toString());
            lore.add(ChatColor.YELLOW + "- Show warp location");
            lore.add(ChatColor.LIGHT_PURPLE + "  (Right click to use) ");
            if (meta.hasLore()) {
                for (final String l : meta.getLore()) {
                    lore.add(l);
                }
            }
            meta.setLore((List)lore);
            item.setItemMeta(meta);
            player.getInventory().addItem(new ItemStack[] { item });
            player.sendMessage(ChatColor.GOLD + "Use the navigation provided");
        }
    }

    public void loadMap() {
        String message = "";
        if (this.data.getConfig().contains("hub")) {
            this.hub = this.data.getConfig().getLocation("hub");
            if (this.hub == null) {
                message = String.valueOf(message) + "Hub [NOT LOADED]";
            }
            else {
                message = String.valueOf(message) + "Hub [LOADED]";
            }
        }
        else {
            message = String.valueOf(message) + "Hub [NOT LOADED]";
            this.hub = null;
        }
        if (this.data.getConfig().contains("skyblock")) {
            this.skyblock = this.data.getConfig().getLocation("skyblock");
            if (this.skyblock == null) {
                message = String.valueOf(message) + ", Skyblock [NOT LOADED]";
            }
            else {
                message = String.valueOf(message) + ", Skyblock [LOADED]";
            }
        }
        else {
            message = String.valueOf(message) + ", Skyblock [NOT LOADED]";
            this.skyblock = null;
        }
        if (this.data.getConfig().contains("skyblock")) {
            this.oneblock = this.data.getConfig().getLocation("oneblock");
            if (this.oneblock == null) {
                message = String.valueOf(message) + ", Oneblock [NOT LOADED]";
            }
            else {
                message = String.valueOf(message) + ", Oneblock [LOADED]";
            }
        }
        else {
            message = String.valueOf(message) + ", Oneblock [NOT LOADED]";
            this.oneblock = null;
        }
        if (this.data.getConfig().contains("minigames")) {
            this.minigames = this.data.getConfig().getLocation("minigames");
            if (this.minigames == null) {
                message = String.valueOf(message) + ", Minigames [NOT LOADED]";
            }
            else {
                message = String.valueOf(message) + ", Minigames [LOADED]";
            }
        }
        else {
            message = String.valueOf(message) + ", Minigames [NOT LOADED]";
            this.minigames = null;
        }
        if (this.data.getConfig().contains("market")) {
            this.market = this.data.getConfig().getLocation("market");
            if (this.skyblock == null) {
                message = String.valueOf(message) + ", Market [NOT LOADED]";
            }
            else {
                message = String.valueOf(message) + ", Market [LOADED]";
            }
        }
        else {
            message = String.valueOf(message) + ", Market [NOT LOADED]";
            this.market = null;
        }
        if (!Bukkit.getOnlinePlayers().isEmpty()) {
            for (final Player online : Bukkit.getOnlinePlayers()) {
                if (online.isOp()) {
                    online.sendMessage(ChatColor.AQUA + message);
                }
            }
        }
    }

    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (label.equalsIgnoreCase("navigate")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Console cannot use this command :/");
                return true;
            }
            final Player player = (Player)sender;
            this.giveNavigationItem(player);
        }
        if (label.equalsIgnoreCase("navigation")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Console cannot use this command :/");
                return true;
            }
            if (!sender.isOp()) {
                sender.sendMessage(ChatColor.RED + "You need to have permission to use this command");
                return true;
            }
            final Player player = (Player)sender;
            try {
                if (args[0].equalsIgnoreCase("create")) {
                    if (args[1].equalsIgnoreCase("hub")) {
                        player.sendMessage(new StringBuilder().append(ChatColor.BLUE).append(ChatColor.BOLD).append("hub").append(player.getLocation()).toString());
                        this.hub = player.getLocation();
                        final Location loc = player.getLocation();
                        player.sendMessage("standing at " + player.getWorld().getBlockAt(loc));
                        this.data.getConfig().set("hub", (Object)loc);
                        this.data.saveConfig();
                    }
                    else if (args[1].equalsIgnoreCase("skyblock")) {
                        player.sendMessage(new StringBuilder().append(ChatColor.BLUE).append(ChatColor.BOLD).append("skyblock").append(player.getLocation()).toString());
                        this.skyblock = player.getLocation();
                        final Location loc = player.getLocation();
                        player.sendMessage("standing at " + player.getWorld().getBlockAt(loc));
                        this.data.getConfig().set("skyblock", (Object)loc);
                        this.data.saveConfig();
                    }
                    else if (args[1].equalsIgnoreCase("oneblock")) {
                        player.sendMessage(new StringBuilder().append(ChatColor.BLUE).append(ChatColor.BOLD).append("oneblock").append(player.getLocation()).toString());
                        this.oneblock = player.getLocation();
                        final Location loc = player.getLocation();
                        player.sendMessage("standing at " + player.getWorld().getBlockAt(loc));
                        this.data.getConfig().set("oneblock", (Object)loc);
                        this.data.saveConfig();
                    }
                    else if (args[1].equalsIgnoreCase("minigames")) {
                        player.sendMessage(new StringBuilder().append(ChatColor.BLUE).append(ChatColor.BOLD).append("minigames").append(player.getLocation()).toString());
                        this.minigames = player.getLocation();
                        final Location loc = player.getLocation();
                        player.sendMessage("standing at " + player.getWorld().getBlockAt(loc));
                        this.data.getConfig().set("minigames", (Object)loc);
                        this.data.saveConfig();
                    }
                    else if (args[1].equalsIgnoreCase("market")) {
                        player.sendMessage(new StringBuilder().append(ChatColor.BLUE).append(ChatColor.BOLD).append("market").append(player.getLocation()).toString());
                        this.market = player.getLocation();
                        final Location loc = player.getLocation();
                        player.sendMessage("standing at " + player.getWorld().getBlockAt(loc));
                        this.data.getConfig().set("market", (Object)loc);
                        this.data.saveConfig();
                    }
                }
                else if (args[0].equalsIgnoreCase("load")) {
                    this.loadMap();
                }
                else if (args[0].equalsIgnoreCase("reset")) {
                    this.resetSavedWarps();
                    player.sendMessage(ChatColor.GREEN + "[NAVIGATION] PLUGIN RESET SUCCESSFUL");
                }
            }
            catch (Exception ex) {}
        }
        return true;
    }

    @EventHandler
    public void rightClickNavigationEvent(final PlayerInteractEvent event) {
        if (event.getAction() == Action.RIGHT_CLICK_AIR) {
            final Player player = event.getPlayer();
            if (player.getInventory().getItemInMainHand().getItemMeta().getDisplayName().contains("Navigation") && player.getInventory().getItemInMainHand().getItemMeta().hasLore()) {
                player.openInventory(this.inv);
            }
        }
    }

    @EventHandler
    public void buyEnchantInventory(final InventoryClickEvent event) {
        if (!event.getInventory().equals(this.inv)) {
            return;
        }
        if (event.getCurrentItem() == null) {
            return;
        }
        if (event.getCurrentItem().getItemMeta() == null) {
            return;
        }
        if (event.getCurrentItem().getItemMeta().getDisplayName() == null) {
            return;
        }
        event.setCancelled(true);
        final Player player = (Player)event.getWhoClicked();
        if (event.getSlot() == 0 && event.getCurrentItem().getItemMeta().getDisplayName().contains("HUB")) {
            if (this.hub != null) {
                player.teleport(this.hub);
            }
            else {
                player.sendMessage(new StringBuilder().append(ChatColor.DARK_RED).append(ChatColor.BOLD).append("[ERROR] WARP DOES NOT EXIST").toString());
            }
        }
        else if (event.getSlot() == 1 && event.getCurrentItem().getItemMeta().getDisplayName().contains("SKY BLOCK")) {
            if (this.skyblock != null) {
                player.teleport(this.skyblock);
            }
            else {
                player.sendMessage(new StringBuilder().append(ChatColor.DARK_RED).append(ChatColor.BOLD).append("[ERROR] WARP DOES NOT EXIST").toString());
            }
        }
        else if (event.getSlot() == 2 && event.getCurrentItem().getItemMeta().getDisplayName().contains("ONE BLOCK")) {
            if (this.oneblock != null) {
                player.teleport(this.oneblock);
            }
            else {
                player.sendMessage(new StringBuilder().append(ChatColor.DARK_RED).append(ChatColor.BOLD).append("[ERROR] WARP DOES NOT EXIST").toString());
            }
        }
        else if (event.getSlot() == 3 && event.getCurrentItem().getItemMeta().getDisplayName().contains("MINIGAMES")) {
            if (this.minigames != null) {
                player.teleport(this.minigames);
            }
            else {
                player.sendMessage(new StringBuilder().append(ChatColor.DARK_RED).append(ChatColor.BOLD).append("[ERROR] WARP DOES NOT EXIST").toString());
            }
        }
        else if (event.getSlot() == 4 && event.getCurrentItem().getItemMeta().getDisplayName().contains("MARKET")) {
            if (this.market != null) {
                player.teleport(this.market);
            }
            else {
                player.sendMessage(new StringBuilder().append(ChatColor.DARK_RED).append(ChatColor.BOLD).append("[ERROR] WARP DOES NOT EXIST").toString());
            }
        }
        else if (event.getSlot() == 8 && event.getCurrentItem().getItemMeta().getDisplayName().contains("Exit")) {
            player.closeInventory();
        }
    }

    public void resetSavedWarps() {
        this.data.getConfig().set("hub", (Object)"");
        this.data.saveConfig();
        this.data.getConfig().set("skyblock", (Object)"");
        this.data.saveConfig();
        this.data.getConfig().set("oneblock", (Object)"");
        this.data.saveConfig();
        this.data.getConfig().set("minigames", (Object)"");
        this.data.saveConfig();
        this.data.getConfig().set("market", (Object)"");
        this.data.saveConfig();
        this.loadMap();
    }
}
